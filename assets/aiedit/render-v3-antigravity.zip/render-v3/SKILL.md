---
name: render-v3
description: Tự động tạo ảnh B-Roll 9:16 và kết xuất video .mp4 hoàn chỉnh từ khối EDL JSON 3.2-mfx-v3-auto mà không hỏi lại bước tiếp theo
---

# Render Video MFX V3.2 Tự Động 100% (Zero-Stop Execution cho Windows & macOS)

Khi người dùng dán khối JSON có `"version": "3.2-mfx-v3-auto"` hoặc gọi `@render-v3` / `/render-v3`, bạn **BẮT BUỘC CHẠY THẲNG ĐẾN KHI XUẤT XONG FILE VIDEO `.MP4`**.

> **QUY TẮC TỐI THƯỢNG (CẤM VI PHẠM):**
> - **TUYỆT ĐỐI KHÔNG DỪNG LẠI** để tóm tắt kịch bản rồi hỏi người dùng *"Bạn muốn làm gì ở bước tiếp theo?"*.
> - **TUYỆT ĐỐI KHÔNG HỎI** tên file video gốc — Engine đã có sẵn thuật toán `Auto-Locate` tự động bỏ qua tên giả (như `"edit-video-v3.mp4"` hay `"AUTO_DETECT"`) và tự động dò đúng file `.mp4` thật trong thư mục hiện tại, `Downloads`, `Desktop` hoặc `Documents`.
> - Thực thi liền một mạch **3 bước bắt buộc** dưới đây trong cùng một phiên làm việc!

---

## Quy Trình 3 Bước Tự Hành Bắt Buộc

### Bước 1: Lưu khối JSON thành file `edl_v3.json`
- Trích xuất nguyên vẹn khối JSON `"version": "3.2-mfx-v3-auto"` mà người dùng vừa gửi và dùng công cụ `write_file` lưu thành file `edl_v3.json` ngay trong thư mục làm việc hiện tại.

### Bước 2: Tự động sinh đủ các ảnh B-Roll dọc `9:16` (`#V1, #V2...`)
- Đọc danh sách `"beats"` trong `edl_v3.json`.
- Với **MỌI nhịp** có `"camera_mode": "broll_kenburns"` (hoặc có `"v_code": "#V1"`, `"#V2"`...):
  - Lấy nội dung `"broll_prompt"` và tên file trong `"broll_asset"` (ví dụ: `v1_scene.png`, `v2_scene.png`...).
  - Nếu trong thư mục `./broll/` chưa có sẵn file ảnh đó, gọi ngay công cụ tạo ảnh (`generate_image` hoặc subagent `image-generator`) để sinh ảnh dọc tỷ lệ `9:16` theo đúng `"broll_prompt"`, rồi lưu vào đường dẫn `broll/v1_scene.png`, `broll/v2_scene.png`...

### Bước 3: Chạy Engine Đa Nền Tảng Để Kết Xuất Thẳng Ra Video `.mp4`
- File script `mfx_v3_universal_engine.py` nằm ngay trong thư mục `scripts/` của kỹ năng `render-v3` này (cùng cấp với file `SKILL.md` bạn đang đọc: `<thư_mục_chứa_SKILL.md>/scripts/mfx_v3_universal_engine.py`).
- Gọi ngay công cụ `run_command` để chạy lệnh kết xuất video (Engine sẽ tự động cài đặt `opencv-python`, `Pillow`, `numpy`, tự động tải `ffmpeg.exe` qua `imageio-ffmpeg` nếu máy Windows chưa có FFmpeg, tự nạp 3 Font chữ + 8 SFX `.wav` đi kèm trong `resources/`, tự động tìm video gốc `.mp4` và xuất ra `<tên_video>_edit_v3.mp4`):

**Trên Windows:**
```powershell
python "<đường_dẫn_tới_skill_render-v3>/scripts/mfx_v3_universal_engine.py" --edl edl_v3.json
```

**Trên macOS / Linux:**
```bash
python3 "<đường_dẫn_tới_skill_render-v3>/scripts/mfx_v3_universal_engine.py" --edl edl_v3.json
```

---

## Báo Cáo Sau Khi Xuất Xong `.mp4`
Chỉ sau khi lệnh ở **Bước 3** chạy xong và in ra dòng `✅ Hoàn tất xuất video MFX V3.2: ... (.mp4)`, bạn mới báo cáo cho người dùng đường dẫn tới:
1. File video hoàn chỉnh: `<tên_video>_edit_v3.mp4`
2. Thư mục ảnh xem trước từng nhịp: `mockups/`
3. Thư mục chữ PNG trong suốt (dành cho người muốn chỉnh thêm trên CapCut): `capcut_png_pack/`
